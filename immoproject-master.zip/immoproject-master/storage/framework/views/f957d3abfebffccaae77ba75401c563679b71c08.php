<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <meta charset="utf-8">
    <link rel="icon" type="image/x-icon" href="/images/favicon.ico">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8">
    <title>Projectimmo - Werde Projektentwickler</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1">
    <meta name="description"
          content="Immobilienmakler für Immobilien deutschlandweit ✔ Kostenlose Bewertung ✔ Individuelle Vermarktung ✔ TÜV-zertifiziert">
    <meta name="robots" content="noindex">

    <meta name="theme-color" content="#000000">



    <link href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
<div id="app">

    <?php echo $__env->yieldContent('content'); ?>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js"></script>
<script src="<?php echo e(mix('/js/app.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\Users\HP\Downloads\immoproject-master\immoproject-master\resources\views/layouts/app.blade.php ENDPATH**/ ?>