<p style="font-size: 1.17em;"><b>Name:</b> {{ $name }}</p>
<p style="font-size: 1.17em;"><b>Email:</b> {{ $email }}</p>
<p style="font-size: 1.17em;"><b>Botschaft:</b> {{ $text }}</p>


