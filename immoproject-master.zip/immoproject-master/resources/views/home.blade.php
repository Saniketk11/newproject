@extends('layouts.app')
@section('content')
    <main-component>

    
    </main-component>
    
@endsection


