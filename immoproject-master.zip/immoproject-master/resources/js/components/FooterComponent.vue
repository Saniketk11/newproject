<template>
    <footer>
        <div class="section-container pd-r-70 pd-l-70 mr-b-50">
            <div class="ft-logo-bar mr-t-20 mr-b-40">
<!--                <img src="/images/footer-logo.png" class="ft-logo">-->
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="flex space-between">
                        <div class="ft-list-box"><p class="ft-title">Menu</p>
                            <ul class="ft-list">
                                <li><a href="#" class="ft-link-item">Start</a></li>
                                <li><a href="#" class="ft-link-item">Leistungen</a></li>
                                <li><a href="#" class="ft-link-item">Unternehmen</a></li>
                                <li><a href="#" class="ft-link-item">Kontakt</a></li>
                            </ul>
                        </div>
                        <div class="ft-list-box"><p class="ft-title"> Rechtliches</p>
                            <ul class="ft-list">
                                <li><a href="#" class="ft-link-item">Impressum</a></li>
                                <li><a href="#" class="ft-link-item">Datenschutz</a></li>
                                <li><a href="#" class="ft-link-item">Cookies</a></li>
                                <li><a href="#" class="ft-link-item">Anmelden</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="ft-content-area">
                        <div class="ft-title-bar"><p class="ft-title"> Kontakt</p></div>
                        <div class="ft-contect-bar">
                            <div class="tell-box"><p class="contect-title">Telefon:</p>
                                <p class="contect-text">+491708080162</p></div>
                            <div class="email-box"><p class="contect-title"> Email:</p>
                                <p class="contect-text">Info@projectimmo.de</p></div>
                        </div>
                        <p class="p-sm-text ">Wir beraten Sie gerne in einem persönlichen Gespräch am Telefon. Sie
                            erreichen uns von Montag bis Freitag von 8:00–20:00 Uhr und an Samstagen von 9:00–18:00
                            Uhr.</p></div>
                </div>
            </div>
        </div>
        <div class="footer-bottom-bar"><p>Copyright © 2022 – PROJECTIMMO</p></div>
    </footer>
</template>

<script>
    export default {
       mounted() {
       }
    }
</script>
