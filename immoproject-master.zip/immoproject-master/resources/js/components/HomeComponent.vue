<template>
    <div>
        <!--        <header-component></header-component>-->
        <head-area-component></head-area-component>
        <main>
            <div>
                <properties-component/>
                <section>
                    <div class="section-container pd-r-70 pd-l-70">
                        <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <h1 class="section-title mr-b-10  ">Vorteile von PROJECTIMMO</h1>
                            </div>
                            <div class="col-md-12 col-lg-12 mt-5">
                                <div class="row">
                                    <div class="col-3 text-center "> 
                                        <div class="projectimmo">
                                         <div class="projectimmo-icon">
                                                <img src="/images/project-icon-2.png" class="wd-100-pt">
                                        </div>
                                       <p> Maximaler Gewinn</p>
                                      </div>
                                    </div>
                                    <div class="col-3 text-center "><div class="projectimmo">
                                         <div class="projectimmo-icon">
                                                <img src="/images/project-icon-2.png" class="wd-100-pt">
                                        </div>
                                         Schnelle Abwicklung</div>
                                         </div>
                                    <div class="col-3 text-center "><div class="projectimmo">Best Service Garantie</div></div>
                                    <div class="col-3 text-center "><div class="projectimmo">Keine Maklerkosten</div></div>
                                </div>
                            </div>
                            <div class="col-md-12 mr-t-40">
                                <img src="/images/section-2-img.jpg" class="wd-100-pt">
                            </div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="section-container pd-l-70 md-pd-r-70">
                        <div class="section-row flex-start md-wd-d-colm">
                            <div class="content-colm-30pt md-wd-100-pt">
                                <div class="ps-absolute wd-600-px relative-md-wd">
                                    <div class="flex wrap"><h1 class="section-title mr-b-10  pd-r-140 pd-r-230 ">Vision,
                                        Mission Werte </h1></div>
                                    <p class="p-text mr-b-30">Unser Ziel ist eine Win-Win-Situation. Durch unser
                                        einzigartiges Konzept erhöhen wir den
                                        Gewinn des Verkäufers, ermöglichen eine schnelle Umsetzung und schaffen
                                        gleichzeitig
                                        hochwertigen Wohnraum. Werde mit PROJECTIMMO zum Immobilienvisionär</p>

                                    <a href="tel:085619186035" class="btn-link">
                                        <svg width="34" height="21" viewBox="0 0 34 21" fill="none"
                                             xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="10.5" cy="10.5" r="9.85" stroke="#182430"
                                                    stroke-width="1.3"></circle>
                                            <path
                                                d="M33.4596 10.4596C33.7135 10.2058 33.7135 9.79422 33.4596 9.54038L29.323 5.40381C29.0692 5.14997 28.6576 5.14997 28.4038 5.40381C28.15 5.65765 28.15 6.0692 28.4038 6.32304L32.0808 10L28.4038 13.677C28.15 13.9308 28.15 14.3424 28.4038 14.5962C28.6576 14.85 29.0692 14.85 29.323 14.5962L33.4596 10.4596ZM7 10.65H33V9.35H7V10.65Z"
                                                fill="black"></path>
                                        </svg>
                                        <span>Mehr über uns erfahren</span></a></div>
                            </div>
                            <div class="img-colm-lgc md-wd-100-pt">
                                <img src="/images/section-4-img.jpg" class="wd-100-pt mr-t-90">
                            </div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="section-container pd-r-70 pd-l-70">
                        <div class="col-md-12 text-center mr-b-40"><h1 class="section-title ">Das sagen unsere
                            Kunden</h1>
                        </div>
                        <div class="row mr-t-30">
                            <div class="col-lg-4 col-md-12 ">
                                <div class="blog-card">
                                    <div class="blog-img">
                                        <img src="/images/olaf.png" class="wd-100-pt">
                                        <div class="stars-bar">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                        </div>
                                    </div>
                                    <div class="blog-content">
                                        <p class="p-text mr-b-20 ft-sz-14">
                                            Ich habe mein Mehrfamilienhaus in Bad Lauchstädt über PROJECTIMMO entwickeln
                                            und verkaufen lassen. Wir konnten mehr als meinen Wunschpreis erzielen und
                                            das Geschäft in wenigen Wochen abwickeln, dazu kommen nette und interessante
                                            Menschen mit denen man arbeiten will.
                                        </p>
                                        <p class="blog-title">Olaf S</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12 ">
                                <div class="blog-card">
                                    <div class="blog-img">
                                        <img src="/images/brigitte.png" class="wd-100-pt">
                                        <div class="stars-bar">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                        </div>
                                    </div>
                                    <div class="blog-content">
                                        <p class="p-text mr-b-20 ft-sz-14">
                                            Mir gefiel besonders, dass ich Teil des Projektes war und ich dadurch neue
                                            Erfahrungen Sammeln konnte mit Menschen die ihre gerne Teilen und Ideen für
                                            nahezu jedes Problem haben. Freue mich auf zukünftige Projekte.
                                        </p>
                                        <p class="blog-title">Brigitte M.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12 ">
                                <div class="blog-card">
                                    <div class="blog-img">
                                        <img src="/images/simon.png" class="wd-100-pt">
                                        <div class="stars-bar">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                            <img src="/images/Star-icon.svg">
                                        </div>
                                    </div>
                                    <div class="blog-content">
                                        <p class="p-text mr-b-20 ft-sz-14">
                                            Das könnte fast zu meinem neuen Hobby werden. Gut gelaunte Mitarbeiter die
                                            einem helfen wirklich das beste aus seinem Objekt zu holen. Bin gespannt wo
                                            die Reise noch hingeht.
                                        </p>
                                        <p class="blog-title">Simon F.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section>
                    <div class="section-container pd-r-70 pd-l-70">
                        <div class="col-md-12 text-center mr-b-80"><h1 class="section-title ">BEKANNT AUS</h1></div>
                        <div class="row mr-t-20 items-center">
                            <div class="col-lg-3 col-md-6">
                                <div class="brands-box">
                                    <img src="/images/brand-img-1.png">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="brands-box">
                                    <img src="/images/brand-img-2.png">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="brands-box">
                                    <img src="/images/brand-img-3.png">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="brands-box">
                                    <img src="/images/brand-img-4.png">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <home-contact-component></home-contact-component>
            </div>
        </main>
        <footer-component></footer-component>
    </div>
</template>

<script>
export default {
    mounted() {
    }
}
</script>
