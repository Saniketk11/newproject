<template>
    <footer class="footer">
        <div class="container">
            <div class="footer__inner">
                <div class="footer__block">
                    <svg viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                         class="css-1hu689b">
                        <path
                            d="M20.1194 8.10663L11.3327 16.8933L6.54602 12.12L4.66602 14L11.3327 20.6666L21.9993 9.99996L20.1194 8.10663ZM13.9993 0.666626C6.63935 0.666626 0.666016 6.63996 0.666016 14C0.666016 21.36 6.63935 27.3333 13.9993 27.3333C21.3594 27.3333 27.3327 21.36 27.3327 14C27.3327 6.63996 21.3594 0.666626 13.9993 0.666626ZM13.9993 24.6666C8.10602 24.6666 3.33268 19.8933 3.33268 14C3.33268 8.10663 8.10602 3.33329 13.9993 3.33329C19.8927 3.33329 24.666 8.10663 24.666 14C24.666 19.8933 19.8927 24.6666 13.9993 24.6666Z"
                            fill="currentColor"></path>
                    </svg>
                    <p>Beratung durch Experten</p>
                </div>
                <div class="footer__block">
                    <svg viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                         class="css-1hu689b">
                        <path
                            d="M20.1194 8.10663L11.3327 16.8933L6.54602 12.12L4.66602 14L11.3327 20.6666L21.9993 9.99996L20.1194 8.10663ZM13.9993 0.666626C6.63935 0.666626 0.666016 6.63996 0.666016 14C0.666016 21.36 6.63935 27.3333 13.9993 27.3333C21.3594 27.3333 27.3327 21.36 27.3327 14C27.3327 6.63996 21.3594 0.666626 13.9993 0.666626ZM13.9993 24.6666C8.10602 24.6666 3.33268 19.8933 3.33268 14C3.33268 8.10663 8.10602 3.33329 13.9993 3.33329C19.8927 3.33329 24.666 8.10663 24.666 14C24.666 19.8933 19.8927 24.6666 13.9993 24.6666Z"
                            fill="currentColor"></path>
                    </svg>
                    <p>Über 100.000 zufriedene Eigentümer</p>
                </div>
                <div class="footer__block">
                    <svg viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                         class="css-1hu689b">
                        <path
                            d="M20.1194 8.10663L11.3327 16.8933L6.54602 12.12L4.66602 14L11.3327 20.6666L21.9993 9.99996L20.1194 8.10663ZM13.9993 0.666626C6.63935 0.666626 0.666016 6.63996 0.666016 14C0.666016 21.36 6.63935 27.3333 13.9993 27.3333C21.3594 27.3333 27.3327 21.36 27.3327 14C27.3327 6.63996 21.3594 0.666626 13.9993 0.666626ZM13.9993 24.6666C8.10602 24.6666 3.33268 19.8933 3.33268 14C3.33268 8.10663 8.10602 3.33329 13.9993 3.33329C19.8927 3.33329 24.666 8.10663 24.666 14C24.666 19.8933 19.8927 24.6666 13.9993 24.6666Z"
                            fill="currentColor"></path>
                    </svg>
                    <p>Kostenlose Immobilienbewertung</p>
                </div>
            </div>

            <div class="d-flex justify-content-center mt-5">
                <img class="footer__img" width="120" height="60"
                     src="https://a.storyblok.com/f/122189/962x471/18c54edd86/trustpilot_dark-bewertung_nummer.png"
                     alt="">
                <img class="footer__img" width="120" height="60"
                     src="https://a.storyblok.com/f/122189/952x388/f8e273fb01/google-reviews-_4-5stars_number.png"
                     alt="">
            </div>

        </div>
    </footer>
</template>

<script>
    export default {
       mounted() {
       }
    }
</script>
